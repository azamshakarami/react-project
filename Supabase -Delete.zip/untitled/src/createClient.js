import {createClient} from "@supabase/supabase-js";



export const supabase=createClient(

    "https://dlgimhfijwbjzsufvuau.supabase.co",
    "sb_publishable_lz5X8KMWDfzXNnEvdc6yOQ_WNYU6l3u")
