import React,{useState,useEffect} from 'react';
import {supabase} from "./createClient.js";
import './App.css'


const App = () => {

    const [users, setUsers] = useState([]);
    const [user,setUser]=useState({ name:'',age:'' });
    console.log(user);

  useEffect(() => {
      fetchUsers()
  },[])

    async function fetchUsers() {
        const {data}=await supabase
            .from("users")
            .select("*")
            setUsers(data);

    }

    function handleChange(event){
      setUser(prevFormData=>{
          return {
              ...prevFormData,
              [event.target.name]: event.target.value
          }
      })
    }

    async function createUser() {
        await supabase
            .from('users')
            .insert({ name: user.name, age: user.age })

        fetchUsers()

    }

    async function deleteUser(userID) {
        const {data,error} = await supabase
            .from('users')
            .delete()
            .eq('id', userID)

        fetchUsers()

        if(error) {
            console.log(error)
        }
        if(data){
            console.log(data)
        }

    }

    return(
        <div>
            <form onSubmit={createUser}>
                <input
                type="text"
                name="name"
                placeholder="Name"
                onChange={handleChange}

                />

                <input
                    type="number"
                    name="age"
                    placeholder="Age"
                    onChange={handleChange}

                />

               <button type="submit">Create</button>
            </form>



            <table className="table">
                <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Age</th>
                    <th>Action</th>
                </tr>
                </thead>

                <tbody>
                {users.map((user) =>
                    <tr key={user.id}>
                        <td>{user.id}</td>
                        <td>{user.name}</td>
                        <td>{user.age}</td>
                        <td><button onClick={()=>{deleteUser(user.id)}}>Delete</button></td>
                    </tr>
                )}


                </tbody>
            </table>
        </div>
    );
}

export default App;